#!/bin/bash

echo 1
exec echo 2
wait
echo 3
