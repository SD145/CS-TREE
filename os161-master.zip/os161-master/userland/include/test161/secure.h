#ifndef _SECURE_H_
#define _SECURE_H_

// Just include the kernel verison
#include <kern/secure.h>

#endif //_SECURE_H_
